package com.trinitarias.Spotifyform.controller;


import com.trinitarias.Spotifyform.dt.FormularioUserDto;
import com.trinitarias.Spotifyform.Service.SpotifyServiceForm;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/formulario")
@CrossOrigin("*") // para permitir peticiones desde el front
public class FormularioController {

    private final SpotifyServiceForm service;

    public FormularioController(SpotifyServiceForm service) {
        this.service = service;
    }

    // ======== CREAR ========
    @PostMapping
    public FormularioUserDto crear(@RequestBody FormularioUserDto dto) {
        return service.crearFormulario(dto);
    }

    // ======== OBTENER POR ID ========
    @GetMapping("/{id}")
    public FormularioUserDto obtenerPorId(@PathVariable Long id) {
        return service.obtenerPorId(id);
    }

    // ======== LISTAR TODOS ========
    @GetMapping
    public List<FormularioUserDto> listarTodos() {
        return service.listarTodos();
    }

    // ======== ACTUALIZAR ========
    @PutMapping("/{id}")
    public FormularioUserDto actualizar(@PathVariable Long id, @RequestBody FormularioUserDto dto) {
        return service.actualizar(id, dto);
    }

    // ======== ELIMINAR ========
    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        service.eliminar(id);
    }
}
